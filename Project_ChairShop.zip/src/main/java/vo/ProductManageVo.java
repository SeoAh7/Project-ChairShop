package vo;

public class ProductManageVo {

	int    pm_idx;
	String p_name;
	int    p_cnt;
	String regdate;
	int    p_idx;
	
	
	public int getP_idx() {
		return p_idx;
	}
	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}
	public int getPm_idx() {
		return pm_idx;
	}
	public void setPm_idx(int pm_idx) {
		this.pm_idx = pm_idx;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public int getP_cnt() {
		return p_cnt;
	}
	public void setP_cnt(int p_cnt) {
		this.p_cnt = p_cnt;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
}

package vo;

public class FaqVo {

	int 	f_idx;		
	String  f_subject;
	String  f_content;
	String  f_regdate;
	String 	m_id; 			
	int 	f_readhit;
	
	
	public int getF_idx() {
		return f_idx;
	}
	public void setF_idx(int f_idx) {
		this.f_idx = f_idx;
	}
	public String getF_subject() {
		return f_subject;
	}
	public void setF_subject(String f_subject) {
		this.f_subject = f_subject;
	}
	public String getF_content() {
		return f_content;
	}
	public void setF_content(String f_content) {
		this.f_content = f_content;
	}
	public String getF_regdate() {
		return f_regdate;
	}
	public void setF_regdate(String f_regdate) {
		this.f_regdate = f_regdate;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public int getF_readhit() {
		return f_readhit;
	}
	public void setF_readhit(int f_readhit) {
		this.f_readhit = f_readhit;
	}
	
	
	
}
